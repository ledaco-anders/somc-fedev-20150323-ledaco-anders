=== somc-subpages-ledaco-anders ===

== Description ==
Display all subpages of the page it's placed on.
If there is an 'featured image', the image will appear next to the title.
You can expand and collapse each level by clicking on the title.
Click on the title to sort each level.

== Tablesorter plugin limitation ==
There is a limitation in the tablesorter plugin that is used for sorting.
The function sorts the highest level in the hierarchy, even if you attempt to sort in a lower.
To fix this you need to build your own JavaScript function or find a plugin that works.